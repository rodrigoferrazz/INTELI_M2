// controllers/homeController.js
const Curriculo = require('../models/curriculoModel');

exports.index = (req, res) => {
  res.render('pages/home');
};

exports.search = async (req, res) => {
  const termo = (req.query.query || '').trim();
  try {
    const curriculos = await Curriculo.findByArea(termo);
    res.render('pages/results', { curriculos, query: termo });
  } catch (err) {
    console.error('Erro ao buscar currículos:', err);
    res.status(500).send(`Erro no servidor: ${err.message}`);
  }
};
